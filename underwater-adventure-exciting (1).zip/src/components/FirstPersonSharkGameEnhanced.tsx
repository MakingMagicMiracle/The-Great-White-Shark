import React, { useState, useEffect, useCallback } from 'react';

interface SwimmingFish {
  id: number;
  x: number;
  y: number;
  z: number;
  type: 'normal' | 'spike' | 'whale';
  emoji: string;
  speed: number;
  color: string;
  vx: number; // velocity x
  vy: number; // velocity y
}

interface FirstPersonSharkGameEnhancedProps {
  sharkType: string;
  onGameOver: () => void;
  onWin: () => void;
}

const FirstPersonSharkGameEnhanced: React.FC<FirstPersonSharkGameEnhancedProps> = ({ 
  sharkType, 
  onGameOver, 
  onWin 
}) => {
  const [gameData, setGameData] = useState({
    level: 1,
    power: 100,
    score: 0,
    lives: 3,
    fishEaten: 0
  });
  
  const [fish, setFish] = useState<SwimmingFish[]>([]);
  const [messages, setMessages] = useState<string[]>([]);

  const tropicalFish = ['🐠', '🐟', '🟨', '🟦', '🟩', '🟪', '🟧', '🔴', '🟡', '🔵', '🟢', '🟣', '🟠', '🐡', '🐙', '🦑', '🦐', '🦀', '🐚', '⭐'];

  const addMessage = useCallback((message: string) => {
    setMessages(prev => [...prev.slice(-2), message]);
    setTimeout(() => setMessages(prev => prev.slice(1)), 3000);
  }, []);

  const spawnFish = useCallback(() => {
    const fishCount = 20 + gameData.level * 3; // Thousands of fish!
    
    for (let i = 0; i < fishCount; i++) {
      const spikeChance = gameData.level < 3 ? 0.05 : 
                         gameData.level < 5 ? 0.1 : 
                         gameData.level < 10 ? 0.15 : 0.25;
      
      const fishType = Math.random() < spikeChance ? 'spike' :
                      Math.random() < 0.02 ? 'whale' : 'normal';
      
      const newFish: SwimmingFish = {
        id: Date.now() + i + Math.random() * 10000,
        x: (Math.random() - 0.5) * 300,
        y: (Math.random() - 0.5) * 200,
        z: 100 + Math.random() * 100,
        type: fishType,
        emoji: fishType === 'spike' ? '🔴🦔' : 
               fishType === 'whale' ? '🐋' :
               tropicalFish[Math.floor(Math.random() * tropicalFish.length)],
        speed: 1 + Math.random() * 2,
        color: `hsl(${Math.random() * 360}, 80%, 60%)`,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2
      };
      
      setFish(prev => [...prev.slice(-150), newFish]);
    }
  }, [gameData.level]);

  // Animate fish swimming towards player with fluid movement
  useEffect(() => {
    const interval = setInterval(() => {
      setFish(prev => prev.map(f => ({
        ...f,
        z: f.z - f.speed,
        x: f.x + f.vx,
        y: f.y + f.vy
      })).filter(f => f.z > -20));
    }, 30); // Smoother animation
    
    return () => clearInterval(interval);
  }, []);

  // Continuous fish spawning
  useEffect(() => {
    const interval = setInterval(spawnFish, 800);
    return () => clearInterval(interval);
  }, [spawnFish]);

  const eatFish = useCallback((fishId: number, fishType: string) => {
    setFish(prev => prev.filter(f => f.id !== fishId));
    
    if (fishType === 'normal') {
      setGameData(prev => ({
        ...prev,
        power: Math.min(150, prev.power + 5),
        score: prev.score + (10 * prev.level),
        fishEaten: prev.fishEaten + 1
      }));
      const msgs = ["Yummy! 🐟", "Great bite! 😋", "Tasty! ⭐"];
      addMessage(msgs[Math.floor(Math.random() * msgs.length)]);
    } else if (fishType === 'spike') {
      setGameData(prev => ({
        ...prev,
        power: Math.max(0, prev.power - 15)
      }));
      addMessage("Ouch! Red spiky! ⚠️");
    }
  }, [addMessage]);

  // Level progression
  useEffect(() => {
    const fishNeeded = gameData.level * 5;
    if (gameData.fishEaten >= fishNeeded && gameData.level < 40) {
      setGameData(prev => ({ ...prev, level: prev.level + 1, fishEaten: 0 }));
      addMessage(`Level ${gameData.level + 1}! 🎉`);
    }
  }, [gameData.fishEaten, gameData.level]);

  // Game over check
  useEffect(() => {
    if (gameData.power <= 0 || gameData.lives <= 0) {
      onGameOver();
    }
    if (gameData.level >= 40) {
      onWin();
    }
  }, [gameData.power, gameData.lives, gameData.level, onGameOver, onWin]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-200 via-blue-500 to-blue-900 relative overflow-hidden">
      {/* Game UI */}
      <div className="absolute top-4 left-4 bg-white/90 p-4 rounded-lg shadow-lg z-50">
        <div className="text-lg font-bold">Level: {gameData.level}/40</div>
        <div className={`text-lg ${gameData.power < 30 ? 'text-red-500' : 'text-green-600'}`}>
          Power: {gameData.power}%
        </div>
        <div className="text-lg">Score: {gameData.score}</div>
        <div className="text-lg">Lives: {'❤️'.repeat(gameData.lives)}</div>
      </div>

      {/* Progress */}
      <div className="absolute top-4 right-4 w-48 bg-white/90 p-2 rounded z-50">
        <div className="text-sm">Fish needed: {Math.max(0, (gameData.level * 5) - gameData.fishEaten)}</div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all"
            style={{ width: `${(gameData.fishEaten / (gameData.level * 5)) * 100}%` }}
          />
        </div>
      </div>

      {/* Messages */}
      <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 z-40">
        {messages.map((msg, i) => (
          <div key={i} className="bg-yellow-400 p-3 rounded-lg mb-2 text-center font-bold animate-bounce">
            {msg}
          </div>
        ))}
      </div>

      {/* Swimming fish from shark's POV */}
      <div className="absolute inset-0">
        {fish.map(f => {
          const scale = Math.max(0.3, 100 / f.z);
          const opacity = Math.min(1, (120 - f.z) / 80);
          
          return (
            <div
              key={f.id}
              className="absolute cursor-pointer transition-all duration-75 hover:scale-125"
              style={{
                left: `${50 + (f.x * scale / 4)}%`,
                top: `${50 + (f.y * scale / 4)}%`,
                fontSize: `${scale * 1.5}rem`,
                opacity: opacity,
                transform: `scale(${scale})`,
                zIndex: Math.floor(100 - f.z)
              }}
              onClick={() => eatFish(f.id, f.type)}
            >
              {f.emoji}
            </div>
          );
        })}
      </div>

      {/* Shark mouth at bottom */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-8xl z-30">
        🦈
      </div>
    </div>
  );
};

export default FirstPersonSharkGameEnhanced;