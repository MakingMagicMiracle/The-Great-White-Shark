import React, { useState, useEffect, useCallback } from 'react';

interface SwimmingFish {
  id: number;
  x: number;
  y: number;
  z: number;
  type: 'normal' | 'spike' | 'whale';
  emoji: string;
  speed: number;
  size: number;
}

interface FirstPersonSharkPOVProps {
  sharkType: string;
  onGameOver: () => void;
  onWin: () => void;
}

const FirstPersonSharkPOV: React.FC<FirstPersonSharkPOVProps> = ({ 
  sharkType, 
  onGameOver, 
  onWin 
}) => {
  const [gameData, setGameData] = useState({
    level: 1,
    power: 100,
    score: 0,
    fishEaten: 0,
    fishThisLevel: 0
  });
  
  const [fish, setFish] = useState<SwimmingFish[]>([]);
  const [messages, setMessages] = useState<string[]>([]);

  const tropicalFish = [
    '🐠', '🐟', '🐡', '🟨', '🟦', '🟩', '🟪', '🟧', '🟡', '🔵', 
    '🟢', '🟣', '🟠', '🐙', '🦑', '🦐', '🦀', '🐚', '⭐', '🌟',
    '💎', '🔶', '🔷', '🔸', '🔹', '🟤', '⚫', '⚪', '🔴', '🟥'
  ];

  const addMessage = useCallback((message: string) => {
    setMessages(prev => [...prev.slice(-2), message]);
    setTimeout(() => setMessages(prev => prev.slice(1)), 2500);
  }, []);

  // Spawn thousands of fish swimming towards the shark
  const spawnFishWave = useCallback(() => {
    const baseCount = 30 + (gameData.level * 5); // More fish each level
    
    for (let i = 0; i < baseCount; i++) {
      // Progressive difficulty for red spiky fish
      const spikeChance = gameData.level <= 2 ? 0.05 : 
                         gameData.level <= 4 ? 0.10 : 
                         gameData.level <= 9 ? 0.15 : 0.25;
      
      const fishType = Math.random() < spikeChance ? 'spike' :
                      Math.random() < 0.03 ? 'whale' : 'normal';
      
      const newFish: SwimmingFish = {
        id: Date.now() + i + Math.random() * 100000,
        x: (Math.random() - 0.5) * 400, // Spread across screen
        y: (Math.random() - 0.5) * 300,
        z: 200 + Math.random() * 300, // Start far away
        type: fishType,
        emoji: fishType === 'spike' ? '🔴🦔' : 
               fishType === 'whale' ? '🐋' :
               tropicalFish[Math.floor(Math.random() * tropicalFish.length)],
        speed: 2 + Math.random() * (1 + gameData.level * 0.3),
        size: fishType === 'whale' ? 3 : fishType === 'spike' ? 1.5 : 1
      };
      
      setFish(prev => [...prev, newFish]);
    }
  }, [gameData.level]);

  // Move fish towards shark continuously
  useEffect(() => {
    const interval = setInterval(() => {
      setFish(prev => prev
        .map(f => ({
          ...f,
          z: f.z - f.speed,
          x: f.x + (Math.random() - 0.5) * 0.5, // Slight swimming motion
          y: f.y + (Math.random() - 0.5) * 0.5
        }))
        .filter(f => f.z > -50) // Remove fish that passed
      );
    }, 50); // Smooth 20fps animation
    
    return () => clearInterval(interval);
  }, []);

  // Continuous spawning
  useEffect(() => {
    const spawnInterval = Math.max(500, 1500 - (gameData.level * 50));
    const interval = setInterval(spawnFishWave, spawnInterval);
    return () => clearInterval(interval);
  }, [spawnFishWave, gameData.level]);

  // Initial spawn
  useEffect(() => {
    spawnFishWave();
  }, [gameData.level]);

  const eatFish = useCallback((fishId: number, fishType: string) => {
    const fishToEat = fish.find(f => f.id === fishId);
    if (!fishToEat) return;

    setFish(prev => prev.filter(f => f.id !== fishId));
    
    if (fishType === 'normal') {
      setGameData(prev => ({
        ...prev,
        power: Math.min(150, prev.power + 3),
        score: prev.score + (10 * prev.level),
        fishEaten: prev.fishEaten + 1,
        fishThisLevel: prev.fishThisLevel + 1
      }));
      
      const encouragingMsgs = [
        "Delicious! 🐟", "Yum! 😋", "Great catch! ⭐", 
        "Tasty fish! 🌟", "Nom nom! 🦈", "Perfect bite! 💎"
      ];
      addMessage(encouragingMsgs[Math.floor(Math.random() * encouragingMsgs.length)]);
      
    } else if (fishType === 'spike') {
      setGameData(prev => ({
        ...prev,
        power: Math.max(0, prev.power - 20)
      }));
      addMessage("OUCH! Spiky fish! ⚠️🔴");
      
    } else if (fishType === 'whale') {
      addMessage("Too big! Avoid whales! 🐋");
      setGameData(prev => ({
        ...prev,
        power: Math.max(0, prev.power - 10)
      }));
    }
  }, [addMessage, fish]);

  // Level progression - need 100 fish per level
  useEffect(() => {
    if (gameData.fishThisLevel >= 100) {
      setGameData(prev => ({ 
        ...prev, 
        level: prev.level + 1, 
        fishThisLevel: 0,
        power: Math.min(150, prev.power + 25) // Bonus power for leveling up
      }));
      addMessage(`🎉 LEVEL ${gameData.level + 1}! 🎉`);
    }
  }, [gameData.fishThisLevel, gameData.level, addMessage]);

  // Game over/win conditions
  useEffect(() => {
    if (gameData.power <= 0) {
      onGameOver();
    }
    if (gameData.level >= 50) {
      onWin();
    }
  }, [gameData.power, gameData.level, onGameOver, onWin]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-300 via-blue-500 to-blue-900 relative overflow-hidden">
      {/* Game Stats */}
      <div className="absolute top-4 left-4 bg-black/70 text-white p-3 rounded-lg z-50">
        <div className="text-xl font-bold">🦈 LEVEL {gameData.level}</div>
        <div className={`text-lg ${gameData.power < 30 ? 'text-red-400' : 'text-green-400'}`}>
          Power: {gameData.power}%
        </div>
        <div className="text-lg">Score: {gameData.score.toLocaleString()}</div>
        <div className="text-sm">Total Fish: {gameData.fishEaten}</div>
      </div>

      {/* Level Progress */}
      <div className="absolute top-4 right-4 w-64 bg-black/70 text-white p-3 rounded-lg z-50">
        <div className="text-sm mb-1">Fish to next level: {100 - gameData.fishThisLevel}</div>
        <div className="w-full bg-gray-600 rounded-full h-3">
          <div 
            className="bg-yellow-400 h-3 rounded-full transition-all duration-300"
            style={{ width: `${(gameData.fishThisLevel / 100) * 100}%` }}
          />
        </div>
      </div>

      {/* Encouraging Messages */}
      <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 z-40 text-center">
        {messages.map((msg, i) => (
          <div key={i} className="bg-yellow-300 text-black p-3 rounded-lg mb-2 font-bold text-lg animate-pulse shadow-lg">
            {msg}
          </div>
        ))}
      </div>

      {/* Fish swimming towards the shark */}
      <div className="absolute inset-0">
        {fish.map(f => {
          const scale = Math.max(0.2, Math.min(3, 150 / f.z)) * f.size;
          const opacity = Math.max(0.3, Math.min(1, (300 - f.z) / 200));
          
          return (
            <div
              key={f.id}
              className="absolute cursor-pointer transition-transform duration-100 hover:scale-110 select-none"
              style={{
                left: `${50 + (f.x * scale / 8)}%`,
                top: `${50 + (f.y * scale / 8)}%`,
                fontSize: `${scale * 2}rem`,
                opacity: opacity,
                zIndex: Math.floor(500 - f.z),
                filter: f.type === 'spike' ? 'drop-shadow(0 0 8px red)' : 
                       f.type === 'whale' ? 'drop-shadow(0 0 8px blue)' : 'none'
              }}
              onClick={() => eatFish(f.id, f.type)}
            >
              {f.emoji}
            </div>
          );
        })}
      </div>
      {/* Shark mouth with teeth and tongue at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-32 z-30">
        {/* Pink tongue */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 w-48 h-20 bg-pink-400 rounded-full opacity-80 z-10" 
             style={{ borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%' }}>
        </div>
        
        {/* White shark teeth */}
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 flex space-x-1 z-20">
          {Array.from({length: 12}).map((_, i) => (
            <div key={i} 
                 className="w-4 h-12 bg-white transform rotate-12 shadow-lg"
                 style={{ 
                   clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
                   transform: `rotate(${-30 + i * 5}deg)`,
                   marginTop: `${Math.abs(i - 6) * 2}px`
                 }}>
            </div>
          ))}
        </div>
      </div>
      {/* Instructions */}
      <div className="absolute bottom-4 left-4 bg-black/70 text-white p-2 rounded text-sm z-50">
        Click fish to eat them! Avoid red spiky fish 🔴🦔 and whales 🐋
      </div>
    </div>
  );
};

export default FirstPersonSharkPOV;