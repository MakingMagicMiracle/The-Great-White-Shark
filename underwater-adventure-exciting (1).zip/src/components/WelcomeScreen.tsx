import React, { useState } from 'react';

interface WelcomeScreenProps {
  onStartGame: (sharkType: string) => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStartGame }) => {
  const [selectedShark, setSelectedShark] = useState<string>('');

  const sharkOptions = [
    { id: 'male1', name: 'Great White Shark Boy #1', emoji: '🦈', gender: 'male', color: 'bg-blue-400' },
    { id: 'male2', name: 'Great White Shark Boy #2', emoji: '🦈', gender: 'male', color: 'bg-blue-600' },
    { id: 'female1', name: 'Great White Shark Girl #1', emoji: '🦈', gender: 'female', color: 'bg-pink-400' },
    { id: 'female2', name: 'Great White Shark Girl #2', emoji: '🦈', gender: 'female', color: 'bg-pink-600' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-300 via-blue-400 to-blue-900 flex flex-col items-center justify-center p-4">
      <div className="text-center mb-8">
        <h1 className="text-5xl font-bold text-white mb-4 drop-shadow-lg">
          🦈 Welcome to the Great White Shark! 🦈
        </h1>
        <p className="text-xl text-white max-w-2xl mx-auto leading-relaxed drop-shadow">
          If you manage to beat the game and win, you will also receive a 
          <span className="font-bold text-yellow-300"> FREE E-Book </span>
          about how to be smarter, think faster, and be better than your school mates!
        </p>
      </div>

      <div className="bg-white/90 p-8 rounded-2xl shadow-2xl max-w-4xl w-full">
        <h2 className="text-3xl font-bold text-center mb-6 text-blue-800">
          Choose Your Shark Character!
        </h2>
        
        <div className="grid grid-cols-2 gap-6 mb-8">
          {sharkOptions.map((shark) => (
            <button
              key={shark.id}
              onClick={() => setSelectedShark(shark.id)}
              className={`p-6 rounded-xl border-4 transition-all duration-300 ${
                selectedShark === shark.id
                  ? 'border-blue-500 bg-blue-100 scale-105'
                  : 'border-gray-300 bg-white hover:border-blue-300 hover:bg-blue-50'
              }`}
            >
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full ${shark.color} flex items-center justify-center`}>
                <div className="text-4xl">{shark.emoji}</div>
              </div>
              <div className="text-xl font-bold text-gray-800">{shark.name}</div>
            </button>
          ))}
        </div>


        {selectedShark && (
          <div className="text-center">
            <button
              onClick={() => onStartGame(selectedShark)}
              className="bg-blue-600 hover:bg-blue-700 text-white text-2xl font-bold py-4 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Start Swimming! 🌊
            </button>
          </div>
        )}
      </div>

      <div className="mt-8 text-center text-white/80 max-w-2xl">
        <p className="text-lg">
          🐟 Eat colorful fish to gain power • ⚠️ Avoid red spiky fish • 🐋 Stay away from whales!
        </p>
      </div>
    </div>
  );
};

export default WelcomeScreen;