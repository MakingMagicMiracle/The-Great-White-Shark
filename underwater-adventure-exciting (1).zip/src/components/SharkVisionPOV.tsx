import React, { useState, useEffect, useCallback } from 'react';

interface CaribbeanFish {
  id: number;
  x: number;
  y: number;
  z: number;
  type: 'normal' | 'spike' | 'whale';
  name: string;
  color: string;
  speed: number;
  size: number;
}

interface SharkVisionPOVProps {
  sharkType: string;
  onGameOver: () => void;
  onWin: () => void;
}

const SharkVisionPOV: React.FC<SharkVisionPOVProps> = ({ 
  sharkType, 
  onGameOver, 
  onWin 
}) => {
  const [gameData, setGameData] = useState({
    level: 1,
    power: 100,
    score: 0,
    fishEaten: 0,
    fishThisLevel: 0
  });
  
  const [fish, setFish] = useState<CaribbeanFish[]>([]);
  const [messages, setMessages] = useState<string[]>([]);
  const [showSharkFlash, setShowSharkFlash] = useState(false);

  // Real Caribbean Sea fish
  const caribbeanFish = [
    { name: 'Parrotfish', color: 'bg-gradient-to-r from-blue-400 to-green-400' },
    { name: 'Angelfish', color: 'bg-gradient-to-r from-yellow-400 to-blue-400' },
    { name: 'Butterflyfish', color: 'bg-gradient-to-r from-yellow-300 to-white' },
    { name: 'Tang', color: 'bg-gradient-to-r from-blue-500 to-purple-400' },
    { name: 'Wrasse', color: 'bg-gradient-to-r from-pink-400 to-orange-400' },
    { name: 'Grouper', color: 'bg-gradient-to-r from-gray-500 to-brown-400' },
    { name: 'Snapper', color: 'bg-gradient-to-r from-red-400 to-pink-400' },
    { name: 'Triggerfish', color: 'bg-gradient-to-r from-blue-600 to-gray-500' },
    { name: 'Surgeonfish', color: 'bg-gradient-to-r from-blue-400 to-black' },
    { name: 'Damselfish', color: 'bg-gradient-to-r from-blue-300 to-yellow-300' }
  ];

  const addMessage = useCallback((message: string) => {
    setMessages(prev => [...prev.slice(-2), message]);
    setTimeout(() => setMessages(prev => prev.slice(1)), 2500);
  }, []);

  // Show shark flash periodically
  useEffect(() => {
    const flashInterval = setInterval(() => {
      setShowSharkFlash(true);
      setTimeout(() => setShowSharkFlash(false), 500);
    }, 6000 + Math.random() * 3000); // Every 6-9 seconds
    
    return () => clearInterval(flashInterval);
  }, []);

  const spawnFishWave = useCallback(() => {
    const baseCount = 25 + (gameData.level * 3);
    
    for (let i = 0; i < baseCount; i++) {
      const spikeChance = gameData.level <= 2 ? 0.05 : 
                         gameData.level <= 4 ? 0.10 : 
                         gameData.level <= 9 ? 0.15 : 0.25;
      
      const fishType = Math.random() < spikeChance ? 'spike' :
                      Math.random() < 0.03 ? 'whale' : 'normal';
      
      const fishData = fishType === 'normal' ? 
        caribbeanFish[Math.floor(Math.random() * caribbeanFish.length)] :
        { name: fishType === 'spike' ? 'Lionfish' : 'Humpback Whale', 
          color: fishType === 'spike' ? 'bg-red-500' : 'bg-gray-700' };

      const newFish: CaribbeanFish = {

        id: Date.now() + i + Math.random() * 100000,
        x: (Math.random() - 0.5) * 400,
        y: (Math.random() - 0.5) * 300,
        z: 200 + Math.random() * 300,
        type: fishType,
        name: fishData.name,
        color: fishData.color,
        speed: 2 + Math.random() * (1 + gameData.level * 0.3),
        size: fishType === 'whale' ? 3 : fishType === 'spike' ? 1.5 : 1
      };
      
      setFish(prev => [...prev, newFish]);
    }
  }, [gameData.level]);

  // Move fish towards shark and check collisions
  useEffect(() => {
    const interval = setInterval(() => {
      setFish(prev => {
        const updatedFish = prev
          .map(f => ({
            ...f,
            z: f.z - f.speed,
            x: f.x + (Math.random() - 0.5) * 0.8,
            y: f.y + (Math.random() - 0.5) * 0.8
          }))
          .filter(f => f.z > -50);

        // Check for collisions (fish close to shark mouth)
        const collisionDistance = 30;
        updatedFish.forEach(f => {
          if (f.z < collisionDistance && Math.abs(f.x) < 50 && Math.abs(f.y) < 50) {
            eatFish(f.id, f.type);
          }
        });

        return updatedFish;
      });
    }, 50);
    
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const spawnInterval = Math.max(400, 1200 - (gameData.level * 40));
    const interval = setInterval(spawnFishWave, spawnInterval);
    return () => clearInterval(interval);
  }, [spawnFishWave, gameData.level]);

  useEffect(() => {
    spawnFishWave();
  }, [gameData.level]);

  const eatFish = useCallback((fishId: number, fishType: string) => {
    const fishToEat = fish.find(f => f.id === fishId);
    if (!fishToEat) return;

    setFish(prev => prev.filter(f => f.id !== fishId));
    
    if (fishType === 'normal') {
      setGameData(prev => ({
        ...prev,
        power: Math.min(150, prev.power + 3),
        score: prev.score + (10 * prev.level),
        fishEaten: prev.fishEaten + 1,
        fishThisLevel: prev.fishThisLevel + 1
      }));
      addMessage(`Ate ${fishToEat.name}! 🐟`);
      
    } else if (fishType === 'spike') {
      setGameData(prev => ({
        ...prev,
        power: Math.max(0, prev.power - 20)
      }));
      addMessage("OUCH! Lionfish spines! ⚠️");
      
    } else if (fishType === 'whale') {
      addMessage("Too big! Avoid whales! 🐋");
      setGameData(prev => ({
        ...prev,
        power: Math.max(0, prev.power - 10)
      }));
    }
  }, [addMessage, fish]);

  useEffect(() => {
    if (gameData.fishThisLevel >= 100) {
      setGameData(prev => ({ 
        ...prev, 
        level: prev.level + 1, 
        fishThisLevel: 0,
        power: Math.min(150, prev.power + 25)
      }));
      addMessage(`🎉 LEVEL ${gameData.level + 1}! 🎉`);
    }
  }, [gameData.fishThisLevel, gameData.level, addMessage]);

  useEffect(() => {
    if (gameData.power <= 0) onGameOver();
    if (gameData.level >= 50) onWin();
  }, [gameData.power, gameData.level, onGameOver, onWin]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-200 via-blue-400 to-blue-800 relative overflow-hidden">
      {/* Shark Flash Overlay - Show actual shark face with teeth */}
      {showSharkFlash && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-blue-900/90">
          <div className="relative">
            <div className="text-9xl">🦈</div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-white text-6xl">⚪⚪⚪</div>
            </div>
          </div>
          <div className="absolute bottom-1/3 text-white text-2xl font-bold animate-pulse">
            GREAT WHITE SHARK VISION
          </div>
        </div>
      )}

      {/* Shark Mouth/Teeth at center bottom - always visible */}
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 z-30">
        <div className="relative">
          <div className="text-9xl">🦈</div>
          {/* Visible teeth */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/4">
            <div className="text-white text-4xl font-bold">▲▲▲▲▲</div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="absolute top-4 left-4 bg-black/70 text-white p-3 rounded-lg z-40">
        <div className="text-xl font-bold">🦈 LEVEL {gameData.level}</div>
        <div className={`text-lg ${gameData.power < 30 ? 'text-red-400' : 'text-green-400'}`}>
          Power: {gameData.power}%
        </div>
        <div className="text-lg">Score: {gameData.score.toLocaleString()}</div>
        <div className="text-sm">Fish Eaten: {gameData.fishEaten}</div>
      </div>

      {/* Progress */}
      <div className="absolute top-4 right-4 w-64 bg-black/70 text-white p-3 rounded-lg z-40">
        <div className="text-sm mb-1">Fish to Level Up: {100 - gameData.fishThisLevel}</div>
        <div className="w-full bg-gray-600 rounded-full h-3">
          <div 
            className="bg-yellow-400 h-3 rounded-full transition-all duration-300"
            style={{ width: `${(gameData.fishThisLevel / 100) * 100}%` }}
          />
        </div>
      </div>

      {/* Messages */}
      <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 z-30 text-center">
        {messages.map((msg, i) => (
          <div key={i} className="bg-yellow-300 text-black p-3 rounded-lg mb-2 font-bold text-lg animate-bounce shadow-lg">
            {msg}
          </div>
        ))}
      </div>

      {/* Caribbean Fish */}
      <div className="absolute inset-0">
        {fish.map(f => {
          const scale = Math.max(0.3, Math.min(4, 180 / f.z)) * f.size;
          const opacity = Math.max(0.4, Math.min(1, (320 - f.z) / 220));
          
          return (
            <div
              key={f.id}
              className={`absolute transition-all duration-150 rounded-full ${f.color} shadow-lg border-2 border-white/30`}
              style={{
                left: `${50 + (f.x * scale / 10)}%`,
                top: `${50 + (f.y * scale / 10)}%`,
                width: `${scale * 3}rem`,
                height: `${scale * 2}rem`,
                opacity: opacity,
                zIndex: Math.floor(400 - f.z),
                filter: f.type === 'spike' ? 'drop-shadow(0 0 12px red)' : 
                       f.type === 'whale' ? 'drop-shadow(0 0 12px blue)' : 
                       'drop-shadow(0 0 4px rgba(0,0,0,0.3))'
              }}
              title={f.name}
            >
              <div className="w-full h-full flex items-center justify-center text-white font-bold text-xs">
                {f.name.charAt(0)}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Instructions */}
      <div className="absolute bottom-4 left-4 bg-black/70 text-white p-2 rounded text-sm z-40">
        <div>🦈 Shark Vision: Fish swim into your mouth!</div>
        <div>⚠️ Avoid Lionfish (red) and Whales</div>
        <div>🎯 Eat 100 fish per level</div>
      </div>
    </div>
  );
};

export default SharkVisionPOV;