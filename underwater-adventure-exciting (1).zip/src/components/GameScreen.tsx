import React, { useState, useEffect, useCallback } from 'react';
import { useGameLogic } from './GameLogic';

interface GameScreenProps {
  sharkType: string;
  onGameOver: () => void;
}

interface Fish {
  id: number;
  x: number;
  y: number;
  type: 'normal' | 'spike' | 'whale';
}

const GameScreen: React.FC<GameScreenProps> = ({ sharkType, onGameOver }) => {
  const [level, setLevel] = useState(1);
  const [power, setPower] = useState(100);
  const [score, setScore] = useState(0);
  const [sharkX, setSharkX] = useState(50);
  const [sharkY, setSharkY] = useState(50);
  const [fish, setFish] = useState<Fish[]>([]);
  const [gameMessage, setGameMessage] = useState('');
  const [superMode, setSuperMode] = useState(false);

  const spawnFish = useCallback(() => {
    const newFish: Fish = {
      id: Date.now(),
      x: Math.random() * 90,
      y: Math.random() * 90,
      type: Math.random() < 0.7 ? 'normal' : Math.random() < 0.9 ? 'spike' : 'whale'
    };
    setFish(prev => [...prev.slice(-10), newFish]);
  }, []);

  useEffect(() => {
    const interval = setInterval(spawnFish, 2000);
    return () => clearInterval(interval);
  }, [spawnFish]);

  const moveTo = (x: number, y: number) => {
    setSharkX(x);
    setSharkY(y);
    
    // Check collisions
    fish.forEach(f => {
      const distance = Math.sqrt((f.x - x) ** 2 + (f.y - y) ** 2);
      if (distance < 8) {
        if (f.type === 'normal') {
          setPower(prev => Math.min(150, prev + 5));
          setScore(prev => prev + 10);
          setGameMessage('Great job! 🐟');
        } else if (f.type === 'spike') {
          setPower(prev => prev - 20);
          setGameMessage('Don\'t touch the RED SPIKIES! ⚠️');
        } else if (f.type === 'whale') {
          setGameMessage('Game Over! Hit by whale! 🐋');
          onGameOver();
        }
        setFish(prev => prev.filter(fish => fish.id !== f.id));
      }
    });
  };

  useEffect(() => {
    if (power <= 0) onGameOver();
    if (power >= 120 && !superMode) {
      setSuperMode(true);
      setGameMessage('Super Speed Mode! 🚀');
      setTimeout(() => setSuperMode(false), power >= 150 ? 20000 : 10000);
    }
  }, [power, superMode, onGameOver]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-300 to-blue-900 relative overflow-hidden">
      <div className="absolute top-4 left-4 bg-white/80 p-4 rounded">
        <div>Level: {level}</div>
        <div>Power: {power}%</div>
        <div>Score: {score}</div>
      </div>
      
      {gameMessage && (
        <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 bg-yellow-400 p-2 rounded text-black font-bold">
          {gameMessage}
        </div>
      )}

      <div 
        className="absolute cursor-pointer text-6xl transition-all duration-300"
        style={{ 
          left: `${sharkX}%`, 
          top: `${sharkY}%`,
          transform: superMode ? 'scale(1.2)' : 'scale(1)'
        }}
        onClick={(e) => {
          const rect = e.currentTarget.parentElement!.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * 100;
          const y = ((e.clientY - rect.top) / rect.height) * 100;
          moveTo(x, y);
        }}
      >
        🦈
      </div>

      {fish.map(f => (
        <div
          key={f.id}
          className="absolute text-3xl"
          style={{ left: `${f.x}%`, top: `${f.y}%` }}
        >
          {f.type === 'normal' ? '🐟' : f.type === 'spike' ? '🔴' : '🐋'}
        </div>
      ))}
    </div>
  );
};

export default GameScreen;