import React, { useState, useEffect, useRef } from 'react';
import AudioManager from './AudioManager';

interface Fish {
  id: number;
  x: number;
  y: number;
  speed: number;
  color: string;
  size: number;
}


const SharkPOVGame: React.FC = () => {
  const [fish, setFish] = useState<Fish[]>([]);
  const [score, setScore] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const audioRef = useRef<HTMLAudioElement>();

  // Fish colors for beautiful Caribbean fish
  const fishColors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
    '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
  ];

  useEffect(() => {
    // Initialize background audio
    audioRef.current = new Audio();
    audioRef.current.loop = true;
    audioRef.current.volume = 0.3;
    
    // Create initial fish
    const initialFish: Fish[] = [];
    for (let i = 0; i < 8; i++) {
      initialFish.push(createFish(i));
    }
    setFish(initialFish);

    // Start game loop
    gameLoop();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  const createFish = (id: number): Fish => ({
    id,
    x: Math.random() * 800 + 800, // Start from right side
    y: Math.random() * 400 + 100,
    speed: Math.random() * 2 + 1,
    color: fishColors[Math.floor(Math.random() * fishColors.length)],
    size: Math.random() * 20 + 15
  });

  const gameLoop = () => {
    updateGame();
    drawGame();
    animationRef.current = requestAnimationFrame(gameLoop);
  };

  const updateGame = () => {
    setFish(prevFish => {
      return prevFish.map(f => {
        const newX = f.x - f.speed;
        
        // Check if fish is eaten (collision with shark mouth)
        if (newX < 200 && f.y > 300 && f.y < 450) {
          setScore(prev => prev + 1);
          return createFish(f.id); // Respawn fish
        }
        
        // Respawn if fish goes off screen
        if (newX < -50) {
          return createFish(f.id);
        }
        
        return { ...f, x: newX };
      });
    });
  };

  const drawGame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw beautiful ocean background
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#87CEEB');
    gradient.addColorStop(0.5, '#4682B4');
    gradient.addColorStop(1, '#191970');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw fish
    fish.forEach(f => {
      ctx.fillStyle = f.color;
      ctx.beginPath();
      ctx.ellipse(f.x, f.y, f.size, f.size * 0.6, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Fish tail
      ctx.beginPath();
      ctx.moveTo(f.x + f.size, f.y);
      ctx.lineTo(f.x + f.size * 1.5, f.y - f.size * 0.5);
      ctx.lineTo(f.x + f.size * 1.5, f.y + f.size * 0.5);
      ctx.closePath();
      ctx.fill();
    });

    // Draw shark teeth (bottom of screen)
    ctx.fillStyle = '#FFFFFF';
    for (let i = 0; i < 15; i++) {
      const x = i * 60 + 30;
      ctx.beginPath();
      ctx.moveTo(x, canvas.height - 80);
      ctx.lineTo(x - 15, canvas.height);
      ctx.lineTo(x + 15, canvas.height);
      ctx.closePath();
      ctx.fill();
    }

    // Draw shark jaw outline
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height + 100, 400, Math.PI, 0);
    ctx.stroke();
  };

  return (
    <div className="relative w-full h-screen bg-blue-900 overflow-hidden">
      <AudioManager isPlaying={true} />
      <canvas
        ref={canvasRef}
        width={800}
        height={600}
        className="absolute inset-0 w-full h-full"
      />
      
      <div className="absolute top-4 left-4 text-white text-xl font-bold">
        Score: {score}
      </div>
      
      <div className="absolute top-4 right-4 text-white text-sm">
        Swim close to eat fish!
      </div>
    </div>
  );
};

export default SharkPOVGame;