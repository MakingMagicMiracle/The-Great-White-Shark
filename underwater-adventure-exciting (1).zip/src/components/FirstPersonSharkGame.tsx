import React, { useState, useEffect, useCallback } from 'react';

interface SwimmingFish {
  id: number;
  x: number;
  y: number;
  z: number; // depth - distance from shark
  type: 'normal' | 'spike' | 'whale';
  emoji: string;
  speed: number;
  color: string;
}

interface FirstPersonSharkGameProps {
  sharkType: string;
  onGameOver: () => void;
  onWin: () => void;
}

const FirstPersonSharkGame: React.FC<FirstPersonSharkGameProps> = ({ 
  sharkType, 
  onGameOver, 
  onWin 
}) => {
  const [gameData, setGameData] = useState({
    level: 1,
    power: 100,
    score: 0,
    lives: 3,
    fishEaten: 0
  });
  
  const [fish, setFish] = useState<SwimmingFish[]>([]);
  const [messages, setMessages] = useState<string[]>([]);

  const tropicalFish = ['🐠', '🐟', '🟨', '🟦', '🟩', '🟪', '🟧', '🔴', '🟡', '🔵', '🟢', '🟣', '🟠', '🐡', '🐙', '🦑', '🦐', '🦀', '🐚', '⭐'];

  const addMessage = useCallback((message: string) => {
    setMessages(prev => [...prev.slice(-2), message]);
    setTimeout(() => setMessages(prev => prev.slice(1)), 3000);
  }, []);

  const spawnFish = useCallback(() => {
    const fishCount = 15 + gameData.level * 2; // More fish at higher levels
    
    for (let i = 0; i < fishCount; i++) {
      const spikeChance = gameData.level < 3 ? 0.05 : 
                         gameData.level < 5 ? 0.1 : 
                         gameData.level < 10 ? 0.15 : 0.25;
      
      const fishType = Math.random() < spikeChance ? 'spike' :
                      Math.random() < 0.02 ? 'whale' : 'normal';
      
      const newFish: SwimmingFish = {
        id: Date.now() + i + Math.random() * 1000,
        x: (Math.random() - 0.5) * 200, // -100 to 100
        y: (Math.random() - 0.5) * 150, // -75 to 75
        z: 100 + Math.random() * 50, // Start far away
        type: fishType,
        emoji: fishType === 'spike' ? '🔴🦔' : 
               fishType === 'whale' ? '🐋' :
               tropicalFish[Math.floor(Math.random() * tropicalFish.length)],
        speed: 0.5 + Math.random() * 1.5,
        color: `hsl(${Math.random() * 360}, 80%, 60%)`
      };
      
      setFish(prev => [...prev.slice(-100), newFish]);
    }
  }, [gameData.level]);

  // Move fish towards player
  useEffect(() => {
    const interval = setInterval(() => {
      setFish(prev => prev.map(f => ({
        ...f,
        z: f.z - f.speed
      })).filter(f => f.z > -10)); // Remove fish that passed
    }, 50);
    
    return () => clearInterval(interval);
  }, []);

  // Spawn fish continuously
  useEffect(() => {
    const interval = setInterval(spawnFish, 1000);
    return () => clearInterval(interval);
  }, [spawnFish]);

  const eatFish = useCallback((fishId: number, fishType: string) => {
    setFish(prev => prev.filter(f => f.id !== fishId));
    
    if (fishType === 'normal') {
      setGameData(prev => ({
        ...prev,
        power: Math.min(150, prev.power + 5),
        score: prev.score + (10 * prev.level),
        fishEaten: prev.fishEaten + 1
      }));
      addMessage("Yummy! 🐟");
    } else if (fishType === 'spike') {
      setGameData(prev => ({
        ...prev,
        power: Math.max(0, prev.power - 15)
      }));
      addMessage("Ouch! Red spiky! ⚠️");
    } else if (fishType === 'whale') {
      setGameData(prev => ({
        ...prev,
        lives: prev.lives - 1
      }));
      addMessage("Too big! 🐋");
    }
  }, [addMessage]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-200 via-blue-500 to-blue-900 relative overflow-hidden">
      {/* UI */}
      <div className="absolute top-4 left-4 bg-white/90 p-4 rounded-lg">
        <div>Level: {gameData.level}/40</div>
        <div>Power: {gameData.power}%</div>
        <div>Score: {gameData.score}</div>
        <div>Lives: {'❤️'.repeat(gameData.lives)}</div>
      </div>

      {/* Messages */}
      <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2">
        {messages.map((msg, i) => (
          <div key={i} className="bg-yellow-400 p-2 rounded mb-2 text-center font-bold">
            {msg}
          </div>
        ))}
      </div>

      {/* Swimming fish from shark's POV */}
      <div className="absolute inset-0">
        {fish.map(f => {
          const scale = Math.max(0.2, 100 / f.z); // Bigger as they get closer
          const opacity = Math.min(1, (100 - f.z) / 50);
          
          return (
            <div
              key={f.id}
              className="absolute cursor-pointer transition-all duration-100 hover:scale-110"
              style={{
                left: `${50 + (f.x * scale)}%`,
                top: `${50 + (f.y * scale)}%`,
                fontSize: `${scale * 2}rem`,
                opacity: opacity,
                transform: `scale(${scale})`,
                zIndex: Math.floor(100 - f.z)
              }}
              onClick={() => eatFish(f.id, f.type)}
            >
              {f.emoji}
            </div>
          );
        })}
      </div>

      {/* Shark mouth indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-6xl">
        🦈
      </div>
    </div>
  );
};

export default FirstPersonSharkGame;