import React, { useState } from 'react';
import WelcomeScreen from './WelcomeScreen';
import SharkVisionPOV from './SharkVisionPOV';
import ConfettiEffect from './ConfettiEffect';
import AudioManager from './AudioManager';

interface SharkGameProps {
  onBack: () => void;
}

const SharkGame: React.FC<SharkGameProps> = ({ onBack }) => {
  const [gameState, setGameState] = useState<'welcome' | 'playing' | 'gameOver' | 'victory'>('welcome');
  const [selectedShark, setSelectedShark] = useState('');
  const startGame = (sharkType: string) => {
    setSelectedShark(sharkType);
    setGameState('playing');
  };

  const handleGameOver = () => {
    setGameState('gameOver');
  };

  const handleVictory = () => {
    setGameState('victory');
  };

  const resetGame = () => {
    setGameState('welcome');
    setSelectedShark('');
  };

  if (gameState === 'welcome') {
    return <WelcomeScreen onStartGame={startGame} />;
  }

  if (gameState === 'playing') {
    return (
      <SharkVisionPOV 
        sharkType={selectedShark} 
        onGameOver={handleGameOver}
        onWin={handleVictory}
      />
    );
  }

  if (gameState === 'victory') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-yellow-300 to-orange-400 flex items-center justify-center">
        <div className="text-center text-white bg-white/20 p-8 rounded-2xl">
          <h2 className="text-6xl font-bold mb-4">🏆 VICTORY! 🏆</h2>
          <p className="text-2xl mb-4">You completed all 40 levels!</p>
          <p className="text-xl mb-6">
            🎁 Claim your FREE E-Book: "How to be Smarter, Think Faster, and Be Better!"
          </p>
          <button 
            onClick={resetGame}
            className="bg-blue-600 hover:bg-blue-700 px-8 py-4 rounded-lg text-2xl font-bold"
          >
            Play Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-400 to-red-800 flex items-center justify-center">
      <div className="text-center text-white bg-white/20 p-8 rounded-2xl">
        <h2 className="text-4xl font-bold mb-4">Game Over!</h2>
        <p className="text-xl mb-6">Don't give up! Try again!</p>
        <button 
          onClick={resetGame}
          className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg text-xl"
        >
          Play Again
        </button>
      </div>
    </div>
  );
};

export default SharkGame;