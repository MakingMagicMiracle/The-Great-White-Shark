import { useState, useEffect, useCallback } from 'react';

export interface GameData {
  level: number;
  power: number;
  score: number;
  lives: number;
  fishEaten: number;
  superModeActive: boolean;
  superModeTimer: number;
}

export interface Fish {
  id: number;
  x: number;
  y: number;
  type: 'normal' | 'spike' | 'whale';
  color: string;
  speed: number;
}

export const useAdvancedGameLogic = (onGameOver: () => void, onLevelComplete: (level: number) => void) => {
  const [gameData, setGameData] = useState<GameData>({
    level: 1,
    power: 100,
    score: 0,
    lives: 3,
    fishEaten: 0,
    superModeActive: false,
    superModeTimer: 0
  });

  const [messages, setMessages] = useState<string[]>([]);
  const [fish, setFish] = useState<Fish[]>([]);
  const [showConfetti, setShowConfetti] = useState(false);

  const addMessage = useCallback((message: string, duration = 3000) => {
    setMessages(prev => [...prev.slice(-2), message]);
    setTimeout(() => {
      setMessages(prev => prev.slice(1));
    }, duration);
  }, []);

  const spawnFish = useCallback(() => {
    const difficulty = Math.min(gameData.level / 10, 1);
    // Spawn many more colorful tropical fish for kids
    const fishCount = Math.floor(8 + difficulty * 12);
    
    for (let i = 0; i < fishCount; i++) {
      // Make red spiky fish rare in early levels for kids
      const spikeChance = gameData.level < 3 ? 0.05 : 
                         gameData.level < 5 ? 0.1 : 
                         gameData.level < 10 ? 0.15 : 0.25;
      
      const newFish: Fish = {
        id: Date.now() + i + Math.random() * 1000,
        x: Math.random() * 90,
        y: Math.random() * 90,
        type: Math.random() < spikeChance ? 'spike' :
              Math.random() < 0.02 ? 'whale' : 'normal',
        color: `hsl(${Math.random() * 360}, 80%, 60%)`,
        speed: 0.5 + difficulty * 0.5
      };
      
      setFish(prev => [...prev.slice(-50), newFish]);
    }
  }, [gameData.level]);

  const eatFish = useCallback(() => {
    setGameData(prev => {
      const newPower = Math.min(150, prev.power + 5);
      const newFishEaten = prev.fishEaten + 1;
      const newScore = prev.score + (10 * prev.level);
      
      return {
        ...prev,
        power: newPower,
        score: newScore,
        fishEaten: newFishEaten
      };
    });
    
    if (Math.random() < 0.4) {
      const messages = ["Great job! 🐟", "Yummy! 😋", "Keep going! 💪", "Awesome! ⭐"];
      addMessage(messages[Math.floor(Math.random() * messages.length)]);
    }
  }, [addMessage]);

  const hitSpike = useCallback(() => {
    setGameData(prev => ({
      ...prev,
      power: Math.max(0, prev.power - 15)
    }));
    addMessage("Don't touch the RED SPIKIES! ⚠️");
  }, [addMessage]);

  const hitWhale = useCallback(() => {
    setGameData(prev => ({
      ...prev,
      lives: prev.lives - 1
    }));
    addMessage("Watch out for whales! 🐋");
  }, [addMessage]);

  // Level progression
  useEffect(() => {
    const fishNeeded = gameData.level * 5;
    if (gameData.fishEaten >= fishNeeded && gameData.level < 40) {
      const newLevel = gameData.level + 1;
      setGameData(prev => ({ ...prev, level: newLevel, fishEaten: 0 }));
      
      if ([10, 20, 30].includes(newLevel)) {
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 3000);
      }
      
      if (newLevel === 10) addMessage("Congrats!! U Made it to level 10! 🎉", 4000);
      if (newLevel === 20) addMessage("Congrats!! U Made it to level 20! 🎉", 4000);
      if (newLevel === 30) addMessage("Congrats!! U Made it to level 30! 🎊", 4000);
      if (newLevel === 40) addMessage("You are almost there kiddo! We have faith you will WIN! 🏆", 5000);
      
      onLevelComplete(newLevel);
    }
  }, [gameData.fishEaten, gameData.level, addMessage, onLevelComplete]);

  // Super mode logic
  useEffect(() => {
    if (gameData.power >= 120 && !gameData.superModeActive) {
      const duration = gameData.power >= 150 ? 20000 : 10000;
      setGameData(prev => ({ 
        ...prev, 
        superModeActive: true, 
        superModeTimer: duration 
      }));
      addMessage(gameData.power >= 150 ? "MAXIMUM POWER! Extra hungry! 🔥" : "Super Speed Mode! 🚀");
    }
  }, [gameData.power, gameData.superModeActive, addMessage]);

  // Super mode timer
  useEffect(() => {
    if (gameData.superModeActive && gameData.superModeTimer > 0) {
      const timer = setTimeout(() => {
        setGameData(prev => ({
          ...prev,
          superModeTimer: prev.superModeTimer - 100
        }));
      }, 100);
      
      if (gameData.superModeTimer <= 0) {
        setGameData(prev => ({ ...prev, superModeActive: false }));
      }
      
      return () => clearTimeout(timer);
    }
  }, [gameData.superModeActive, gameData.superModeTimer]);

  // Game over conditions
  useEffect(() => {
    if (gameData.power <= 0 || gameData.lives <= 0) {
      onGameOver();
    }
  }, [gameData.power, gameData.lives, onGameOver]);

  // Fish spawning - faster for more tropical fish
  useEffect(() => {
    const interval = setInterval(spawnFish, Math.max(500, 2000 - gameData.level * 30));
    return () => clearInterval(interval);
  }, [spawnFish, gameData.level]);

  return {
    gameData,
    messages,
    fish,
    showConfetti,
    eatFish,
    hitSpike,
    hitWhale,
    addMessage,
    setFish
  };
};