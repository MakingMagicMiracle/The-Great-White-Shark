import React from 'react';
import SharkPOVGame from './SharkPOVGame';

const AppLayout: React.FC = () => {
  return (
    <div className="w-full h-screen">
      <SharkPOVGame />
    </div>
  );
};

export default AppLayout;