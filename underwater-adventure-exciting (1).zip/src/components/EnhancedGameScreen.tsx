import React, { useState, useCallback, useEffect } from 'react';
import { useAdvancedGameLogic, Fish } from './AdvancedGameLogic';
import { useAudioManager } from './AudioManager';
import ConfettiEffect from './ConfettiEffect';

interface EnhancedGameScreenProps {
  sharkType: string;
  onGameOver: () => void;
  onWin: () => void;
}

const EnhancedGameScreen: React.FC<EnhancedGameScreenProps> = ({ 
  sharkType, 
  onGameOver, 
  onWin 
}) => {
  const [sharkX, setSharkX] = useState(50);
  const [sharkY, setSharkY] = useState(50);
  const [sharkDirection, setSharkDirection] = useState(0);

  const onLevelComplete = useCallback((level: number) => {
    if (level >= 40) {
      onWin();
    }
  }, [onWin]);

  const {
    gameData,
    messages,
    fish,
    showConfetti,
    eatFish,
    hitSpike,
    hitWhale,
    addMessage,
    setFish
  } = useAdvancedGameLogic(onGameOver, onLevelComplete);

  const sharkGender = sharkType.includes('female') ? 'female' : 'male';
  
  const { playLevelMessage } = useAudioManager({
    gameData,
    sharkGender,
    onMessage: addMessage
  });

  const moveTo = useCallback((clientX: number, clientY: number, rect: DOMRect) => {
    const x = ((clientX - rect.left) / rect.width) * 100;
    const y = ((clientY - rect.top) / rect.height) * 100;
    
    // Calculate direction for shark rotation
    const dx = x - sharkX;
    const dy = y - sharkY;
    const angle = Math.atan2(dy, dx) * (180 / Math.PI);
    setSharkDirection(angle);
    
    setSharkX(x);
    setSharkY(y);
    
    // Check collisions
    fish.forEach(f => {
      const distance = Math.sqrt((f.x - x) ** 2 + (f.y - y) ** 2);
      if (distance < 6) {
        if (f.type === 'normal') {
          eatFish();
        } else if (f.type === 'spike') {
          hitSpike();
        } else if (f.type === 'whale') {
          hitWhale();
        }
        setFish(prev => prev.filter(fish => fish.id !== f.id));
      }
    });
  }, [sharkX, sharkY, fish, eatFish, hitSpike, hitWhale, setFish]);

  // Level completion messages
  useEffect(() => {
    if ([10, 20, 30, 40].includes(gameData.level)) {
      playLevelMessage(gameData.level);
    }
  }, [gameData.level, playLevelMessage]);

  const getSharkEmoji = () => {
    if (sharkType.includes('male1')) return '🦈';
    if (sharkType.includes('male2')) return '🦈';
    if (sharkType.includes('female1')) return '🦈';
    return '🦈';
  };

  const getFishEmoji = (fish: Fish) => {
    if (fish.type === 'normal') {
      const tropicalFish = ['🐠', '🐟', '🟨', '🟦', '🟩', '🟪', '🟧', '🔴', '🟡', '🔵', '🟢', '🟣', '🟠', '🐡', '🐙', '🦑', '🦐', '🦀', '🐚', '⭐'];
      return tropicalFish[fish.id % tropicalFish.length];
    }
    if (fish.type === 'spike') return '🔴🦔'; // Red spiky fish that kills power
    return '🐋';
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-300 via-blue-400 to-blue-900 relative overflow-hidden">
      <ConfettiEffect show={showConfetti} />
      
      {/* Game UI */}
      <div className="absolute top-4 left-4 bg-white/90 p-4 rounded-lg shadow-lg">
        <div className="text-lg font-bold">Level: {gameData.level}/40</div>
        <div className={`text-lg ${gameData.power < 30 ? 'text-red-500' : 'text-green-600'}`}>
          Power: {gameData.power}%
        </div>
        <div className="text-lg">Score: {gameData.score}</div>
        <div className="text-lg">Lives: {'❤️'.repeat(gameData.lives)}</div>
        {gameData.superModeActive && (
          <div className="text-red-500 font-bold animate-pulse">
            SUPER MODE: {Math.ceil(gameData.superModeTimer / 1000)}s
          </div>
        )}
      </div>

      {/* Progress bar */}
      <div className="absolute top-4 right-4 w-48 bg-white/90 p-2 rounded">
        <div className="text-sm">Fish needed: {Math.max(0, (gameData.level * 5) - gameData.fishEaten)}</div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all"
            style={{ width: `${(gameData.fishEaten / (gameData.level * 5)) * 100}%` }}
          />
        </div>
      </div>
      
      {/* Messages */}
      <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 space-y-2">
        {messages.map((message, index) => (
          <div 
            key={index}
            className="bg-yellow-400 p-3 rounded-lg text-black font-bold text-center animate-bounce"
          >
            {message}
          </div>
        ))}
      </div>

      {/* Game area */}
      <div 
        className="absolute inset-0 cursor-pointer"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          moveTo(e.clientX, e.clientY, rect);
        }}
      >
        {/* Shark */}
        <div 
          className={`absolute text-6xl transition-all duration-300 ${
            gameData.superModeActive ? 'animate-pulse scale-125' : ''
          }`}
          style={{ 
            left: `${sharkX}%`, 
            top: `${sharkY}%`,
            transform: `rotate(${sharkDirection}deg)`,
            filter: gameData.superModeActive ? 'drop-shadow(0 0 10px #ff6b6b)' : 'none'
          }}
        >
          {getSharkEmoji()}
        </div>

        {/* Fish */}
        {fish.map(f => (
          <div
            key={f.id}
            className="absolute text-2xl animate-pulse"
            style={{ 
              left: `${f.x}%`, 
              top: `${f.y}%`,
              color: f.type === 'normal' ? f.color : undefined
            }}
          >
            {getFishEmoji(f)}
          </div>
        ))}
      </div>
    </div>
  );
};

export default EnhancedGameScreen;