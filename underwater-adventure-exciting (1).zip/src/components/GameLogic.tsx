import { useState, useEffect } from 'react';

export interface GameData {
  level: number;
  power: number;
  score: number;
  lives: number;
}

export const useGameLogic = () => {
  const [gameData, setGameData] = useState<GameData>({
    level: 1,
    power: 100,
    score: 0,
    lives: 3
  });

  const [messages, setMessages] = useState<string[]>([]);

  const addMessage = (message: string) => {
    setMessages(prev => [...prev.slice(-2), message]);
    setTimeout(() => {
      setMessages(prev => prev.slice(1));
    }, 3000);
  };

  const eatFish = () => {
    setGameData(prev => ({
      ...prev,
      power: Math.min(150, prev.power + 5),
      score: prev.score + 10
    }));
    
    if (Math.random() < 0.3) {
      addMessage("Great job! 🐟");
    }
  };

  const hitSpike = () => {
    setGameData(prev => ({
      ...prev,
      power: Math.max(0, prev.power - 20)
    }));
    addMessage("Don't touch the RED SPIKIES! ⚠️");
  };

  const levelUp = () => {
    setGameData(prev => ({
      ...prev,
      level: prev.level + 1
    }));

    const { level } = gameData;
    if (level === 10) addMessage("Congrats!! U Made it to level 10! 🎉");
    if (level === 20) addMessage("Congrats!! U Made it to level 20! 🎉");
    if (level === 30) addMessage("Congrats!! U Made it to level 30! 🎊");
    if (level === 40) addMessage("You are almost there kiddo! We have faith you will WIN! 🏆");
  };

  const checkSuperMode = () => {
    return gameData.power >= 120;
  };

  const isGameOver = () => {
    return gameData.power <= 0;
  };

  return {
    gameData,
    messages,
    eatFish,
    hitSpike,
    levelUp,
    checkSuperMode,
    isGameOver,
    addMessage
  };
};

export default useGameLogic;