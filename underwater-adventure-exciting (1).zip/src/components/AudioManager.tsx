import { useEffect, useRef } from 'react';

interface AudioManagerProps {
  isPlaying: boolean;
}

const AudioManager: React.FC<AudioManagerProps> = ({ isPlaying }) => {
  const audioRef = useRef<HTMLAudioElement>();

  useEffect(() => {
    // Create audio context for ocean sounds
    audioRef.current = new Audio();
    audioRef.current.loop = true;
    audioRef.current.volume = 0.3;
    
    // Use data URL for simple ocean-like sound
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.setValueAtTime(200, audioContext.currentTime);
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    
    if (isPlaying) {
      oscillator.start();
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      try {
        oscillator.stop();
        audioContext.close();
      } catch (e) {
        // Ignore errors on cleanup
      }
    };
  }, [isPlaying]);

  return null;
};

export default AudioManager;